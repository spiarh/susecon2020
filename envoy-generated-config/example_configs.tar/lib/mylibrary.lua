M = {}

function M.foobar()
    return "bar"
end

return M
